package com.student.controller;

import com.student.dao.DocumentDAO;
import com.student.model.Document;
import com.student.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {
    
    private DocumentDAO documentDAO = new DocumentDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        System.out.println("DownloadServlet: User " + user.getUsername() + " đang tải tài liệu");
        
        String docIdParam = request.getParameter("docId");
        if (docIdParam == null || docIdParam.isEmpty()) {
            System.out.println("DownloadServlet: Không có docId");
            response.sendRedirect("documents");
            return;
        }
        
        try {
            int docId = Integer.parseInt(docIdParam);
            System.out.println("DownloadServlet: docId = " + docId);
            
            Document document = documentDAO.getDocumentById(docId);
            
            if (document == null) {
                System.out.println("DownloadServlet: Không tìm thấy tài liệu với ID = " + docId);
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println("<h3>Không tìm thấy tài liệu!</h3>");
                response.getWriter().println("<a href='documents'>Quay lại</a>");
                return;
            }
            
            System.out.println("DownloadServlet: Tài liệu tìm thấy - " + document.getTitle());
            System.out.println("DownloadServlet: File path = " + document.getFilePath());
            
            // Lấy đường dẫn file thực tế
            String applicationPath = request.getServletContext().getRealPath("");
            String filePath = applicationPath + File.separator + document.getFilePath();
            File file = new File(filePath);
            
            System.out.println("DownloadServlet: Đường dẫn tuyệt đối = " + file.getAbsolutePath());
            System.out.println("DownloadServlet: File tồn tại = " + file.exists());
            
            if (file.exists()) {
                // Set header cho download
                String mimeType = getServletContext().getMimeType(file.getName());
                if (mimeType == null) {
                    mimeType = "application/octet-stream";
                }
                
                response.setContentType(mimeType);
                response.setHeader("Content-Disposition", "attachment; filename=\"" + 
                                    URLEncoder.encode(document.getFileName(), "UTF-8").replaceAll("\\+", " ") + "\"");
                response.setContentLength((int) file.length());
                
                // Ghi file ra response
                try (FileInputStream fis = new FileInputStream(file);
                     ServletOutputStream os = response.getOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, bytesRead);
                    }
                    os.flush();
                }
                System.out.println("DownloadServlet: Tải file thành công!");
            } else {
                System.out.println("DownloadServlet: File không tồn tại tại đường dẫn: " + file.getAbsolutePath());
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println("<h3>File không tồn tại trên server!</h3>");
                response.getWriter().println("<p>Đường dẫn: " + file.getAbsolutePath() + "</p>");
                response.getWriter().println("<a href='documents'>Quay lại danh sách tài liệu</a>");
            }
        } catch (NumberFormatException e) {
            System.out.println("DownloadServlet: Lỗi định dạng docId: " + e.getMessage());
            response.sendRedirect("documents");
        } catch (Exception e) {
            System.out.println("DownloadServlet: Lỗi không xác định: " + e.getMessage());
            e.printStackTrace();
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<h3>Đã xảy ra lỗi: " + e.getMessage() + "</h3>");
            response.getWriter().println("<a href='documents'>Quay lại</a>");
        }
    }
    
    // Hỗ trợ POST method (chuyển sang GET)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}