package com.student.controller;

import com.student.dao.ExerciseDAO;
import com.student.model.Exercise;
import com.student.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/addExercise")
public class AddExerciseServlet extends HttpServlet {
    
    private ExerciseDAO exerciseDAO = new ExerciseDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập và quyền admin
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect("home");
            return;
        }
        
        request.getRequestDispatcher("admin_add_exercise.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập và quyền admin
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect("home");
            return;
        }
        
        // Lấy dữ liệu từ form
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String difficulty = request.getParameter("difficulty");
        
        // Kiểm tra dữ liệu
        if (title == null || title.trim().isEmpty()) {
            request.setAttribute("error", "Vui lòng nhập tiêu đề bài tập!");
            request.getRequestDispatcher("admin_add_exercise.jsp").forward(request, response);
            return;
        }
        
        // Tạo đối tượng Exercise
        Exercise exercise = new Exercise();
        exercise.setTitle(title);
        exercise.setDescription(description);
        exercise.setDifficulty(difficulty);
        
        // Lưu vào database (cần thêm method addExercise vào ExerciseDAO)
        if (exerciseDAO.addExercise(exercise)) {
            request.setAttribute("message", "Thêm bài tập thành công!");
        } else {
            request.setAttribute("error", "Thêm bài tập thất bại!");
        }
        
        request.getRequestDispatcher("admin_add_exercise.jsp").forward(request, response);
    }
}