package com.student.controller;

import com.student.dao.DocumentDAO;
import com.student.dao.SubmissionDAO;
import com.student.model.Document;
import com.student.model.Submission;
import com.student.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Date;

@WebServlet("/upload")
@MultipartConfig(maxFileSize = 1024 * 1024 * 10) // 10MB
public class UploadServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads/submissions";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login");
            return;
        }

        int exerciseId = Integer.parseInt(request.getParameter("exerciseId"));

        Part filePart = request.getPart("file");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        // Đường dẫn lưu file
        String appPath = request.getServletContext().getRealPath("");
        String uploadPath = appPath + File.separator + UPLOAD_DIR;

        File folder = new File(uploadPath);
        if (!folder.exists()) folder.mkdirs();

        String filePath = uploadPath + File.separator + fileName;
        filePart.write(filePath);

        // Lưu DB Submission
        Submission submission = new Submission();

        submission.setStudentId(user.getId());   // ⚠️ sửa ở đây
        submission.setExerciseId(exerciseId);
        submission.setFileName(fileName);
        submission.setFilePath("uploads/submissions/" + fileName);

        // ⚠️ Date → String
        submission.setSubmitDate(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                .format(new java.util.Date()));

        SubmissionDAO submissionDAO = new SubmissionDAO();
        submissionDAO.saveSubmission(submission);

        // 🔥 THÔNG BÁO THÀNH CÔNG
        response.sendRedirect("exercises?success=1");
    }
}