package com.student.controller;

import com.student.dao.ExerciseDAO;
import com.student.model.Exercise;
import com.student.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    private ExerciseDAO exerciseDAO = new ExerciseDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        // Lấy danh sách bài tập để hiển thị trên trang chủ (có thể lấy 3 bài mới nhất)
        List<Exercise> recentExercises = exerciseDAO.getAllExercises();
        if (recentExercises.size() > 3) {
            recentExercises = recentExercises.subList(0, 3);
        }
        
        request.setAttribute("recentExercises", recentExercises);
        request.getRequestDispatcher("home.jsp").forward(request, response);
    }
}