package com.student.controller;

import com.student.dao.DocumentDAO;
import com.student.model.Document;
import com.student.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.IOException;

@WebServlet("/uploadDocument")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
public class UploadDocumentServlet extends HttpServlet {
    
    private static final String UPLOAD_DIR = "uploads/documents";
    private DocumentDAO documentDAO = new DocumentDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect("home");
            return;
        }
        request.getRequestDispatcher("admin_upload_document.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect("home");
            return;
        }
        
        String title = request.getParameter("title");
        int exerciseId = Integer.parseInt(request.getParameter("exerciseId"));
        Part filePart = request.getPart("file");
        
        if (filePart == null || filePart.getSize() == 0) {
            request.setAttribute("error", "Vui lòng chọn file!");
            request.getRequestDispatcher("admin_upload_document.jsp").forward(request, response);
            return;
        }
        
        String fileName = extractFileName(filePart);
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadPath = applicationPath + File.separator + UPLOAD_DIR;
        
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();
        
        String uniqueFileName = System.currentTimeMillis() + "_" + fileName;
        String filePath = uploadPath + File.separator + uniqueFileName;
        filePart.write(filePath);
        
        Document doc = new Document();
        doc.setTitle(title);
        doc.setFileName(fileName);
        doc.setFilePath(UPLOAD_DIR + "/" + uniqueFileName);
        doc.setExerciseId(exerciseId);
        doc.setUploadedBy(user.getId());
        
        if (documentDAO.addDocument(doc)) {
            request.setAttribute("message", "Upload thành công!");
        } else {
            request.setAttribute("error", "Upload thất bại!");
        }
        
        request.getRequestDispatcher("admin_upload_document.jsp").forward(request, response);
    }
    
    private String extractFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        for (String token : contentDisposition.split(";")) {
            if (token.trim().startsWith("filename")) {
                String fileName = token.substring(token.indexOf("=") + 2, token.length() - 1);
                return fileName.substring(fileName.lastIndexOf("\\") + 1);
            }
        }
        return "unknown";
    }
}