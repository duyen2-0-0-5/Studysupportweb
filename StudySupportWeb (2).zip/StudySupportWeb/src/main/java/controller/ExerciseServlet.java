package com.student.controller;

import com.student.dao.ExerciseDAO;
import com.student.model.Exercise;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/exercises")
public class ExerciseServlet extends HttpServlet {
    private ExerciseDAO exerciseDAO = new ExerciseDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        String difficulty = request.getParameter("difficulty");
        List<Exercise> exercises;
        
        if (difficulty != null && !difficulty.isEmpty()) {
            exercises = exerciseDAO.getExercisesByDifficulty(difficulty);
            request.setAttribute("filterDifficulty", difficulty);
        } else {
            exercises = exerciseDAO.getAllExercises();
        }
        
        request.setAttribute("exercises", exercises);
        request.getRequestDispatcher("exercises.jsp").forward(request, response);
    }
}