package com.student.controller;

import com.student.dao.DocumentDAO;
import com.student.model.Document;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/documents")
public class DocumentServlet extends HttpServlet {
    private DocumentDAO documentDAO = new DocumentDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        String exerciseIdParam = request.getParameter("exerciseId");
        List<Document> documents;
        
        if (exerciseIdParam != null && !exerciseIdParam.isEmpty()) {
            int exerciseId = Integer.parseInt(exerciseIdParam);
            documents = documentDAO.getDocumentsByExercise(exerciseId);
            request.setAttribute("exerciseId", exerciseId);
        } else {
            documents = documentDAO.getAllDocuments();
        }
        
        request.setAttribute("documents", documents);
        request.getRequestDispatcher("documents.jsp").forward(request, response);
    }
}