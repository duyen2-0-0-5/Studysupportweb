package com.student.controller;

import com.student.dao.DocumentDAO;
import com.student.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.IOException;

@WebServlet("/deleteDocument")
public class DeleteDocumentServlet extends HttpServlet {
    
    private DocumentDAO documentDAO = new DocumentDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect("home");
            return;
        }
        
        String docIdParam = request.getParameter("docId");
        if (docIdParam != null && !docIdParam.isEmpty()) {
            int docId = Integer.parseInt(docIdParam);
            var doc = documentDAO.getDocumentById(docId);
            if (doc != null) {
                String applicationPath = request.getServletContext().getRealPath("");
                String filePath = applicationPath + File.separator + doc.getFilePath();
                new File(filePath).delete();
                documentDAO.deleteDocument(docId);
            }
        }
        response.sendRedirect("documents");
    }
}