package com.student.dao;

import com.student.model.User;
import java.sql.*;

public class UserDAO {
    
    public boolean registerUser(User user) {
        String sql = "INSERT INTO users (username, fullname, email, password, role) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getFullname());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getRole());
            
            System.out.println(">>> Register SQL: " + ps.toString());
            int result = ps.executeUpdate();
            System.out.println(">>> Register result: " + result);
            return result > 0;
        } catch (SQLException e) {
            System.out.println(">>> Register ERROR: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public User loginUser(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            
            System.out.println(">>> Login SQL: " + ps.toString());
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                System.out.println(">>> User found in database!");
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setFullname(rs.getString("fullname"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                return user;
            } else {
                System.out.println(">>> User NOT found!");
                return null;
            }
        } catch (SQLException e) {
            System.out.println(">>> Login ERROR: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public boolean isUsernameExists(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}