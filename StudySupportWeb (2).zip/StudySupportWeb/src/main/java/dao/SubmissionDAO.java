package com.student.dao;

import com.student.model.Submission;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubmissionDAO {

    public boolean saveSubmission(Submission submission) {
        String sql = "INSERT INTO submissions (exercise_id, student_id, file_name, file_path, submit_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, submission.getExerciseId());
            ps.setInt(2, submission.getStudentId());
            ps.setString(3, submission.getFileName());
            ps.setString(4, submission.getFilePath());
            ps.setString(5, submission.getSubmitDate());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean hasSubmitted(int exerciseId, int studentId) {
        String sql = "SELECT * FROM submissions WHERE exercise_id=? AND student_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, exerciseId);
            ps.setInt(2, studentId);
            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Submission getSubmission(int exerciseId, int studentId) {
        String sql = "SELECT * FROM submissions WHERE exercise_id=? AND student_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, exerciseId);
            ps.setInt(2, studentId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Submission sub = new Submission();
                sub.setId(rs.getInt("id"));
                sub.setExerciseId(rs.getInt("exercise_id"));
                sub.setStudentId(rs.getInt("student_id"));
                sub.setFileName(rs.getString("file_name"));
                sub.setFilePath(rs.getString("file_path"));
                sub.setSubmitDate(rs.getString("submit_date"));
                return sub;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Submission> getSubmissionsByStudent(int studentId) {
        List<Submission> list = new ArrayList<>();
        String sql = "SELECT * FROM submissions WHERE student_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Submission sub = new Submission();
                sub.setId(rs.getInt("id"));
                sub.setExerciseId(rs.getInt("exercise_id"));
                sub.setStudentId(rs.getInt("student_id"));
                sub.setFileName(rs.getString("file_name"));
                sub.setFilePath(rs.getString("file_path"));
                sub.setSubmitDate(rs.getString("submit_date"));
                list.add(sub);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}