package com.student.dao;

import com.student.model.Document;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DocumentDAO {
    
    public List<Document> getDocumentsByExercise(int exerciseId) {
        List<Document> documents = new ArrayList<>();
        String sql = "SELECT * FROM documents WHERE exercise_id = ? ORDER BY upload_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, exerciseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Document doc = new Document();
                doc.setId(rs.getInt("id"));
                doc.setTitle(rs.getString("title"));
                doc.setFileName(rs.getString("file_name"));
                doc.setFilePath(rs.getString("file_path"));
                doc.setExerciseId(rs.getInt("exercise_id"));
                doc.setUploadedBy(rs.getInt("uploaded_by"));
                doc.setUploadDate(rs.getString("upload_date"));
                documents.add(doc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return documents;
    }
    
    public List<Document> getAllDocuments() {
        List<Document> documents = new ArrayList<>();
        String sql = "SELECT * FROM documents ORDER BY upload_date DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Document doc = new Document();
                doc.setId(rs.getInt("id"));
                doc.setTitle(rs.getString("title"));
                doc.setFileName(rs.getString("file_name"));
                doc.setFilePath(rs.getString("file_path"));
                doc.setExerciseId(rs.getInt("exercise_id"));
                doc.setUploadedBy(rs.getInt("uploaded_by"));
                doc.setUploadDate(rs.getString("upload_date"));
                documents.add(doc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return documents;
    }
    
    // ============= THÊM METHOD NÀY =============
    /**
     * Lấy tài liệu theo ID
     * @param id ID của tài liệu cần lấy
     * @return Document object hoặc null nếu không tìm thấy
     */
    public Document getDocumentById(int id) {
        String sql = "SELECT * FROM documents WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Document doc = new Document();
                doc.setId(rs.getInt("id"));
                doc.setTitle(rs.getString("title"));
                doc.setFileName(rs.getString("file_name"));
                doc.setFilePath(rs.getString("file_path"));
                doc.setExerciseId(rs.getInt("exercise_id"));
                doc.setUploadedBy(rs.getInt("uploaded_by"));
                doc.setUploadDate(rs.getString("upload_date"));
                return doc;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Thêm tài liệu mới (dành cho admin)
     */
    public boolean addDocument(Document document) {
        String sql = "INSERT INTO documents (title, file_name, file_path, exercise_id, uploaded_by) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, document.getTitle());
            ps.setString(2, document.getFileName());
            ps.setString(3, document.getFilePath());
            ps.setInt(4, document.getExerciseId());
            ps.setInt(5, document.getUploadedBy());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Xóa tài liệu theo ID
     */
    public boolean deleteDocument(int id) {
        String sql = "DELETE FROM documents WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Cập nhật thông tin tài liệu
     */
    public boolean updateDocument(Document document) {
        String sql = "UPDATE documents SET title = ?, file_name = ?, file_path = ?, exercise_id = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, document.getTitle());
            ps.setString(2, document.getFileName());
            ps.setString(3, document.getFilePath());
            ps.setInt(4, document.getExerciseId());
            ps.setInt(5, document.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Đếm số lượng tài liệu theo bài tập
     */
    public int countDocumentsByExercise(int exerciseId) {
        String sql = "SELECT COUNT(*) FROM documents WHERE exercise_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, exerciseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}