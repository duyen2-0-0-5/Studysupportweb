package com.student.dao;

import com.student.model.Exercise;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExerciseDAO {
    
    public List<Exercise> getAllExercises() {
        List<Exercise> exercises = new ArrayList<>();
        String sql = "SELECT * FROM exercises ORDER BY id";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Exercise exercise = new Exercise();
                exercise.setId(rs.getInt("id"));
                exercise.setTitle(rs.getString("title"));
                exercise.setDescription(rs.getString("description"));
                exercise.setDifficulty(rs.getString("difficulty"));
                exercises.add(exercise);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exercises;
    }
    
    public Exercise getExerciseById(int id) {
        String sql = "SELECT * FROM exercises WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Exercise exercise = new Exercise();
                exercise.setId(rs.getInt("id"));
                exercise.setTitle(rs.getString("title"));
                exercise.setDescription(rs.getString("description"));
                exercise.setDifficulty(rs.getString("difficulty"));
                return exercise;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Exercise> getExercisesByDifficulty(String difficulty) {
        List<Exercise> exercises = new ArrayList<>();
        String sql = "SELECT * FROM exercises WHERE difficulty = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, difficulty);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Exercise exercise = new Exercise();
                exercise.setId(rs.getInt("id"));
                exercise.setTitle(rs.getString("title"));
                exercise.setDescription(rs.getString("description"));
                exercise.setDifficulty(rs.getString("difficulty"));
                exercises.add(exercise);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exercises;
    }
    
    // ============= THÊM METHOD NÀY =============
    /**
     * Thêm bài tập mới vào database
     * @param exercise Đối tượng Exercise cần thêm
     * @return true nếu thêm thành công, false nếu thất bại
     */
    public boolean addExercise(Exercise exercise) {
        String sql = "INSERT INTO exercises (title, description, difficulty) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, exercise.getTitle());
            ps.setString(2, exercise.getDescription());
            ps.setString(3, exercise.getDifficulty());
            
            int result = ps.executeUpdate();
            System.out.println("AddExercise result: " + result);
            return result > 0;
        } catch (SQLException e) {
            System.out.println("Lỗi khi thêm bài tập: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Xóa bài tập theo ID
     * @param id ID của bài tập cần xóa
     * @return true nếu xóa thành công, false nếu thất bại
     */
    public boolean deleteExercise(int id) {
        String sql = "DELETE FROM exercises WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Cập nhật bài tập
     * @param exercise Đối tượng Exercise cần cập nhật
     * @return true nếu cập nhật thành công, false nếu thất bại
     */
    public boolean updateExercise(Exercise exercise) {
        String sql = "UPDATE exercises SET title = ?, description = ?, difficulty = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, exercise.getTitle());
            ps.setString(2, exercise.getDescription());
            ps.setString(3, exercise.getDifficulty());
            ps.setInt(4, exercise.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}