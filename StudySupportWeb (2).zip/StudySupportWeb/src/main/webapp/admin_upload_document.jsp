<%@ page import="com.student.model.User, com.student.dao.ExerciseDAO, com.student.model.Exercise, java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if(user == null || !"admin".equals(user.getRole())) {
        response.sendRedirect("login");
        return;
    }
    ExerciseDAO exerciseDAO = new ExerciseDAO();
    List<Exercise> exercises = exerciseDAO.getAllExercises();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upload tài liệu - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home"><i class="fas fa-graduation-cap"></i> Admin Panel</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="exercises"><i class="fas fa-tasks"></i> Bài tập</a>
                <a class="nav-link" href="documents"><i class="fas fa-file-alt"></i> Tài liệu</a>
                <a class="nav-link" href="logout"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-upload"></i> Upload tài liệu mới</h4>
                    </div>
                    <div class="card-body">
                        <% if(request.getAttribute("message") != null) { %>
                            <div class="alert alert-success"><%= request.getAttribute("message") %></div>
                        <% } %>
                        <% if(request.getAttribute("error") != null) { %>
                            <div class="alert alert-danger"><%= request.getAttribute("error") %></div>
                        <% } %>
                        
                        <form action="uploadDocument" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Tiêu đề tài liệu *</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Chọn bài tập liên quan *</label>
                                <select name="exerciseId" class="form-select" required>
                                    <option value="">-- Chọn bài tập --</option>
                                    <% for(Exercise ex : exercises) { %>
                                        <option value="<%= ex.getId() %>"><%= ex.getTitle() %></option>
                                    <% } %>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Chọn file tài liệu *</label>
                                <input type="file" name="file" class="form-control" accept=".pdf,.zip,.rar,.doc,.docx" required>
                                <small class="text-muted">Hỗ trợ: PDF, ZIP, RAR, DOC, DOCX (tối đa 10MB)</small>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
                            <a href="documents" class="btn btn-secondary">Quay lại</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>