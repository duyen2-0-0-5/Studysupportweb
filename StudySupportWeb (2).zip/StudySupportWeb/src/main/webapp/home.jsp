<%@ page import="com.student.model.User, com.student.model.Exercise, java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if(user == null) {
        response.sendRedirect("login");
        return;
    }
    List<Exercise> recentExercises = (List<Exercise>) request.getAttribute("recentExercises");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang chủ - Student Support</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
        }
        .feature-card {
            transition: transform 0.3s;
        }
        .feature-card:hover {
            transform: translateY(-10px);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="home">
                <i class="fas fa-graduation-cap"></i> Student Support
            </a>
            <div class="navbar-nav ms-auto">
                <span class="nav-link text-white">
                    <i class="fas fa-user"></i> Xin chào, <%= user.getFullname() %>
                </span>
                <a class="nav-link" href="logout">
                    <i class="fas fa-sign-out-alt"></i> Đăng xuất
                </a>
            </div>
        </div>
    </nav>
    
    <div class="hero-section">
        <div class="container text-center">
            <h1 class="display-4">🎓 Chào mừng đến với Student Support</h1>
            <p class="lead">Hệ thống hỗ trợ học tập dành cho sinh viên Công nghệ Thông tin</p>
        </div>
    </div>
    
    <div class="container my-5">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card feature-card h-100 text-center shadow-sm">
                    <div class="card-body">
                        <i class="fas fa-tasks fa-3x text-primary mb-3"></i>
                        <h5 class="card-title">Bài tập thực hành</h5>
                        <p class="card-text">Xem danh sách bài tập theo độ khó, tải tài liệu hướng dẫn giải</p>
                        <a href="exercises" class="btn btn-primary">Xem bài tập →</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card feature-card h-100 text-center shadow-sm">
                    <div class="card-body">
                        <i class="fas fa-file-alt fa-3x text-success mb-3"></i>
                        <h5 class="card-title">Tài liệu học tập</h5>
                        <p class="card-text">Tải tài liệu, đề bài, bài giải mẫu cho từng bài tập</p>
                        <a href="documents" class="btn btn-success">Xem tài liệu →</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card feature-card h-100 text-center shadow-sm">
                    <div class="card-body">
                        <i class="fas fa-chart-line fa-3x text-info mb-3"></i>
                        <h5 class="card-title">Tiến độ học tập</h5>
                        <p class="card-text">Theo dõi tiến độ hoàn thành bài tập của bạn</p>
                        <button class="btn btn-info text-white" onclick="alert('Tính năng đang phát triển!')">Xem tiến độ →</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <p class="mb-0">© 2025 Student Support - Hệ thống hỗ trợ học tập CNTT</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>