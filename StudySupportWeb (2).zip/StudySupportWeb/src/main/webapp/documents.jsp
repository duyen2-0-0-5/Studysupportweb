<%@ page import="java.util.List, com.student.model.Document, com.student.model.User" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if(user == null) {
        response.sendRedirect("login");
        return;
    }
    List<Document> documents = (List<Document>) request.getAttribute("documents");
    Integer exerciseId = (Integer) request.getAttribute("exerciseId");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tài liệu - Student Support</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="home">Student Support</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="exercises">Bài tập</a>
                <a class="nav-link" href="home">Trang chủ</a>
                <a class="nav-link" href="logout">Đăng xuất</a>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        
        <!-- Nút upload tài liệu - chỉ admin -->
        <% if("admin".equals(user.getRole())) { %>
            <div class="mb-4 text-end">
                <a href="uploadDocument" class="btn btn-success">
                    <i class="fas fa-upload"></i> + Upload tài liệu mới
                </a>
            </div>
        <% } %>
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-file-alt"></i> Tài liệu hỗ trợ</h2>
            <a href="exercises" class="btn btn-secondary">← Quay lại bài tập</a>
        </div>
        
        <% if(documents == null || documents.isEmpty()) { %>
            <div class="alert alert-info text-center">Chưa có tài liệu nào!</div>
        <% } else { %>
            <div class="row">
                <% for(Document doc : documents) { %>
                <div class="col-md-6 mb-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <i class="fas fa-file-pdf fa-3x text-danger"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-1"><%= doc.getTitle() %></h5>
                                    <p class="text-muted small mb-1"><%= doc.getFileName() %></p>
                                    <p class="text-muted small">Ngày đăng: <%= doc.getUploadDate() %></p>
                                </div>
                                <div>
                                    <!-- LINK TẢI ĐÚNG -->
                                    <a href="download?docId=<%= doc.getId() %>" class="btn btn-primary">
                                        <i class="fas fa-download"></i> Tải file
                                    </a>
                                    <!-- Nút xóa cho admin -->
                                    <% if("admin".equals(user.getRole())) { %>
                                        <a href="deleteDocument?docId=<%= doc.getId() %>" 
                                           class="btn btn-danger btn-sm mt-2"
                                           onclick="return confirm('Xóa tài liệu này?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    <% } %>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <% } %>
            </div>
        <% } %>
    </div>
</body>
</html>