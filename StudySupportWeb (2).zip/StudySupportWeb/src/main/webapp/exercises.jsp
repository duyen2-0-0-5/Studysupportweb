<%@ page import="java.util.List, com.student.model.Exercise, com.student.model.User, com.student.dao.SubmissionDAO, com.student.model.Submission" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if(user == null) {
        response.sendRedirect("login");
        return;
    }
    List<Exercise> exercises = (List<Exercise>) request.getAttribute("exercises");
    String filterDifficulty = (String) request.getAttribute("filterDifficulty");
    
    // Kiểm tra đã nộp bài chưa
    SubmissionDAO submissionDAO = new SubmissionDAO();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bài tập - Student Support</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .difficulty-easy { border-left: 4px solid #28a745; }
        .difficulty-medium { border-left: 4px solid #ffc107; }
        .difficulty-hard { border-left: 4px solid #dc3545; }
        .card { transition: transform 0.2s; position: relative; }
        .card:hover { transform: translateY(-5px); }
        .submitted-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 11px;
            z-index: 10;
        }
        .admin-buttons {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 10;
        }
        .admin-buttons .btn {
            padding: 2px 6px;
            font-size: 11px;
            margin-right: 3px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="home">
                <i class="fas fa-graduation-cap"></i> Student Support
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="home">
                    <i class="fas fa-home"></i> Trang chủ
                </a>
                <a class="nav-link" href="logout">
                    <i class="fas fa-sign-out-alt"></i> Đăng xuất
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        
        <!-- ============= NÚT THÊM BÀI TẬP - CHỈ HIỂN THỊ VỚI ADMIN ============= -->
        <% if("admin".equals(user.getRole())) { %>
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <h2>
                        <i class="fas fa-tasks"></i> Bài tập thực hành
                    </h2>
                    <a href="addExercise" class="btn btn-success">
                        <i class="fas fa-plus-circle"></i> + Thêm bài tập mới
                    </a>
                </div>
            </div>
        <% } else { %>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>
                    <i class="fas fa-tasks"></i> Bài tập thực hành
                </h2>
            </div>
        <% } %>
        
        <!-- Hiển thị thông báo -->
        <% if(request.getAttribute("message") != null) { %>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i> <%= request.getAttribute("message") %>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <% } %>
        <% if(request.getAttribute("error") != null) { %>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle"></i> <%= request.getAttribute("error") %>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <% } %>
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="dropdown">
                <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-filter"></i> Lọc theo độ khó
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="exercises">📋 Tất cả</a></li>
                    <li><a class="dropdown-item" href="exercises?difficulty=Dễ">✅ Dễ</a></li>
                    <li><a class="dropdown-item" href="exercises?difficulty=Trung bình">⚠️ Trung bình</a></li>
                    <li><a class="dropdown-item" href="exercises?difficulty=Khó">🔥 Khó</a></li>
                </ul>
            </div>
        </div>
        
        <% if(filterDifficulty != null) { %>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Đang hiển thị bài tập độ khó: <strong><%= filterDifficulty %></strong>
                <a href="exercises" class="float-end">Xóa bộ lọc</a>
            </div>
        <% } %>
        
        <div class="row">
            <% if(exercises == null || exercises.isEmpty()) { %>
                <div class="col-12">
                    <div class="alert alert-warning text-center">
                        <i class="fas fa-exclamation-triangle"></i> Chưa có bài tập nào.
                        <% if("admin".equals(user.getRole())) { %>
                            <a href="addExercise" class="alert-link">Hãy thêm bài tập đầu tiên!</a>
                        <% } %>
                    </div>
                </div>
            <% } else { %>
                <% for(Exercise exercise : exercises) { 
                    String difficultyClass = "";
                    String difficultyIcon = "";
                    String badgeClass = "";
                    boolean hasSubmitted = submissionDAO.hasSubmitted(exercise.getId(), user.getId());
                    Submission submission = null;
                    if(hasSubmitted) {
                        submission = submissionDAO.getSubmission(exercise.getId(), user.getId());
                    }
                    
                    if("Dễ".equals(exercise.getDifficulty())) {
                        difficultyClass = "difficulty-easy";
                        difficultyIcon = "✅";
                        badgeClass = "bg-success";
                    } else if("Trung bình".equals(exercise.getDifficulty())) {
                        difficultyClass = "difficulty-medium";
                        difficultyIcon = "⚠️";
                        badgeClass = "bg-warning";
                    } else if("Khó".equals(exercise.getDifficulty())) {
                        difficultyClass = "difficulty-hard";
                        difficultyIcon = "🔥";
                        badgeClass = "bg-danger";
                    } else {
                        difficultyClass = "difficulty-medium";
                        difficultyIcon = "📝";
                        badgeClass = "bg-secondary";
                    }
                %>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm <%= difficultyClass %>">
                        <% if(hasSubmitted) { %>
                            <div class="submitted-badge">
                                <i class="fas fa-check-circle"></i> Đã nộp
                            </div>
                        <% } %>
                        
                        <!-- Nút xóa bài tập - chỉ admin -->
                        <% if("admin".equals(user.getRole())) { %>
                            <div class="admin-buttons">
                                <a href="deleteExercise?id=<%= exercise.getId() %>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Bạn có chắc muốn xóa bài tập "<%= exercise.getTitle() %>" này?')">
                                    <i class="fas fa-trash"></i> Xóa
                                </a>
                            </div>
                        <% } %>
                        
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title text-primary">
                                    <i class="fas fa-code"></i> <%= exercise.getTitle() %>
                                </h5>
                                <span class="badge <%= badgeClass %>">
                                    <%= difficultyIcon %> <%= exercise.getDifficulty() %>
                                </span>
                            </div>
                            <p class="card-text text-muted">
                                <small><i class="fas fa-pencil-alt"></i> Mô tả:</small><br>
                                <%= exercise.getDescription() %>
                            </p>
                            
                            <!-- Nút Tải tài liệu -->
                            <div class="mt-3">
                                <a href="documents?exerciseId=<%= exercise.getId() %>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-download"></i> Tải tài liệu
                                </a>
                            </div>
                            
                            <!-- Hiển thị thông tin bài đã nộp (nếu có) -->
                            <% if(hasSubmitted && submission != null) { %>
                                <div class="submission-info mt-2 p-2 bg-light rounded">
                                    <small>
                                        <i class="fas fa-file-upload"></i> Bài đã nộp: 
                                        <strong><%= submission.getFileName() %></strong><br>
                                        <i class="fas fa-calendar-alt"></i> Ngày nộp: <%= submission.getSubmitDate() %>
                                        <% if(submission.getGrade() > 0) { %>
                                            <br><i class="fas fa-star"></i> Điểm: <strong class="text-success"><%= submission.getGrade() %></strong>
                                        <% } %>
                                    </small>
                                </div>
                            <% } %>
                            
                            <!-- Form Nộp bài tập -->
                            <div class="mt-3">
                                <form action="upload" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="exerciseId" value="<%= exercise.getId() %>">
                                    <div class="input-group input-group-sm">
                                        <input type="file" name="file" class="form-control" 
                                               accept=".pdf,.zip,.rar,.doc,.docx,.java,.txt" 
                                               <%= hasSubmitted ? "disabled" : "" %> required>
                                        <button type="submit" class="btn btn-sm <%= hasSubmitted ? "btn-secondary" : "btn-success" %>" 
                                                <%= hasSubmitted ? "disabled" : "" %>>
                                            <i class="fas fa-upload"></i> <%= hasSubmitted ? "Đã nộp" : "Nộp bài" %>
                                        </button>
                                    </div>
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle"></i> Chấp nhận: PDF, ZIP, DOC, JAVA (tối đa 10MB)
                                    </small>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <% } %>
            <% } %>
        </div>
        
        <!-- Thống kê -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-simple"></i>
                        Tổng số bài tập: <strong><%= exercises != null ? exercises.size() : 0 %></strong> | 
                        Đã nộp: <strong class="text-success">
                            <% 
                                int submittedCount = 0;
                                if(exercises != null) {
                                    for(Exercise ex : exercises) {
                                        if(submissionDAO.hasSubmitted(ex.getId(), user.getId())) submittedCount++;
                                    }
                                }
                            %>
                            <%= submittedCount %>
                        </strong> | 
                        Chưa nộp: <strong class="text-warning"><%= (exercises != null ? exercises.size() : 0) - submittedCount %></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <p class="mb-0">© 2025 Student Support - Hệ thống hỗ trợ học tập CNTT</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>